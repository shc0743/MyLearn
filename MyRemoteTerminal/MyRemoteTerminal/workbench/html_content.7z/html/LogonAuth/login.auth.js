(document.getElementById('main') || {}).style.display = '';
(document.getElementById('iForgotMyPassword') || {}).onclick = function () {

    return false
}

